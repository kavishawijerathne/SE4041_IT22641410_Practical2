package com.example.lab02

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class BillCalculatorActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bill_calculator)

        val etUnits = findViewById<EditText>(R.id.etUnits)
        val btnCalculate = findViewById<Button>(R.id.btnCalculate)
        val tvResult = findViewById<TextView>(R.id.tvResult)

        btnCalculate.setOnClickListener {
            val inputUnits = etUnits.text.toString()

            if (inputUnits.isNotEmpty()) {
                val units = inputUnits.toDouble()

                // Constants
                val fixedCharge = 150.0
                val unitCost = 29.0
                val vatRate = 0.15

                // Calculations
                val energyCharge = units * unitCost
                val subtotal = fixedCharge + energyCharge
                val vat = subtotal * vatRate
                val totalBill = subtotal + vat

                // Display result formatted to 2 decimal places
                tvResult.text = String.format("Electricity Bill: LKR %.2f", totalBill)
            } else {
                Toast.makeText(this, "Please enter units!", Toast.LENGTH_SHORT).show()
            }
        }
    }
}